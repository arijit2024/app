<?php /*Template Name: Home*/ ?>
<?php get_header() ?>
    <!-- main start  -->
    <main>
      <!-- first section start  -->
      <section
        class="first-sec"
        style="
          background-image: url(<?php the_field('header_add_background') ?>);
          background-position: center center;
          background-size: cover;
        "
      >
        <div class="container">
          <div class="banner-content-wrapper">
            <div class="banner-content-text">
            <?php if( get_field('header_add_heading') ): ?>	
                <h1 id="animated-heading"><?php the_field('header_add_heading') ?></h1>
            <?php endif; ?>
            <?php if( get_field('header_add_sub_heading') ): ?>	
                <p><?php the_field('header_add_sub_heading') ?></p>
            <?php endif; ?>
            </div>
            <?php if( get_field('header_add_button_text') ): ?>	
                <a href="<?php the_field('header_add_button_link') ?>" class="red-button"><?php the_field('header_add_button_text') ?></a>
            <?php endif; ?>
          </div>
        </div>
      </section>
      <!-- first section end  -->
      <!-- secound section start  -->
      <section class="secound-sec" style="background-image: url(<?php the_field('secound_section_add_background') ?>)">
        <div class="container">
          <div class="secound-sec-row">
            <div class="secound-sec-left">
                <?php if( get_field('secound_section_add_heading') ): ?>	
                    <h2><?php the_field('secound_section_add_heading') ?></h2>
                <?php endif; ?>
              <div class="sec-line"></div>
            </div>
            <div class="secound-sec-right">
                <?php if( get_field('secound_section_add_content') ): ?>	
                    <?php the_field('secound_section_add_content') ?>
                <?php endif; ?>
                <?php if( get_field('secound_section_add_button_text') ): ?>	
                    <div class="learn-more-button">
                      <a href="<?php the_field('secound_section_add_button_text_url') ?>" class="border-button"><?php the_field('secound_section_add_button_text') ?></a>
                    </div>
                <?php endif; ?>
            </div>
          </div>
        </div>
      </section>
      <!-- secound section end  -->
      <!-- third section start  -->
      <section class="third-sec">
        <div class="container">
          <div class="third-sec-wrapper">

            <?php while( have_rows('third_section_add_card') ): the_row(); 
                $third_section_card_heading = get_sub_field('third_section_card_heading');
                $third_section_card_name = get_sub_field('third_section_card_name');
                $third_section_card_image = get_sub_field('third_section_card_image');
                $third_section_card_position = get_sub_field('third_section_card_position');
                $third_section_card_content = get_sub_field('third_section_card_content');
                $third_section_card_button_text = get_sub_field('third_section_card_button_text');
            ?>
                <div class="third-wrapper-left">
                  <div class="third-heading">
                    <h3><?php echo $third_section_card_heading ?></h3>
                    <div class="third-line"></div>
                  </div>
                  <div class="third-sec-card">
                    <div class="third-sec-card-top">
                      <div class="third-sec-card-top-img">
                        <img src="<?php echo esc_url($third_section_card_image['url']); ?>" />
                      </div>
                      <div class="third-sec-card-top-name">
                        <h4><?php echo $third_section_card_name ?></h4>
                        <h5><?php echo $third_section_card_position ?></h5>
                      </div>
                    </div>
                    <div class="third-sec-card-btm">
                      <p><?php echo $third_section_card_content ?></p>
                      <a href="<?php echo $third_section_card_button_text_link ?>" class="know-more"
                        ><?php echo $third_section_card_button_text ?> <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/left-errow.svg"
                      /></a>
                    </div>
                  </div>
                </div>
            <?php endwhile; ?>

          </div>
        </div>
      </section>
      <!-- third section end  -->
      <!-- fourth section start  -->
      <section class="fourth-sec">
        <div class="container">
            <?php if( get_field('fourth_section_heading') ): ?>	
                <div class="heading">
                  <h2><?php the_field('fourth_section_heading') ?></h2>
                </div>
            <?php endif; ?>
        </div>
        <div class="fourth-sec-slider">
          <div class="owl-carousel owl-theme slide-one">
            <?php while( have_rows('fourth_section_card') ): the_row(); 
                $fourth_section_image = get_sub_field('fourth_section_image');
                $fourth_section_heading = get_sub_field('fourth_section_heading');
                $fourth_section_content = get_sub_field('fourth_section_content');
                $fourth_section_icon = get_sub_field('fourth_section_icon');
                $fourth_section_link = get_sub_field('fourth_section_link');
            ?>
                    <div class="item">
                    <div class="slider-cont-wrapper">
                        <div class="slider-img">
                            <img src="<?php echo esc_url($fourth_section_image['url']); ?>" />
                        </div>
                        <div class="slide-content">
                        <div class="icon-with-circle">
                            <img src="<?php echo esc_url($fourth_section_icon['url']); ?>" />
                        </div>
                        <div class="slide-content-text">
                            <h3><?php echo $fourth_section_heading ?></h3>
                            <p><?php echo $fourth_section_content ?></p>
                        </div> 
                        </div>
                    </div>
                    </div>
                <?php endwhile; ?>
          </div>
        </div>
      </section>
      <!-- fourth section end  -->
      <!-- fifth section start -->
      <section class="fifth-sec">
        <div class="container">
            <?php if( get_field('fifth_section_hrading') ): ?>	
                <div class="heading-cration">
                  <h2><?php the_field('fifth_section_hrading') ?></h2>
                </div>
            <?php endif; ?>
          <div class="our-value-wrapper">
          <div class="row">
            <div class="col-xxl-5 col-xl-5 col-lg-5 col-md-6 col-sm-12">
                <ul class="nav nav-tabs" id="valueTabs" role="tablist">
                    <?php 
                    $i = 0; 
                    while (have_rows('fifth_section_add_tabs')): 
                        the_row(); 
                        $fifth_section_text = get_sub_field('fifth_section_add_text'); 
                        $tab_id = 'tab-' . $i; 
                    ?> 
                        <li class="nav-item" role="presentation">
                            <a
                                class="nav-link <?= ($i === 0) ? 'active' : '' ?>"
                                id="<?= $tab_id ?>-tab"
                                data-bs-toggle="tab"
                                href="#<?= $tab_id ?>"
                                role="tab"
                                aria-controls="<?= $tab_id ?>"
                                aria-selected="<?= ($i === 0) ? 'true' : 'false' ?>"
                            >
                                <?php echo esc_html($fifth_section_text); ?>
                            </a>
                        </li>
                    <?php 
                        $i++; 
                    endwhile; 
                    ?>
                </ul>
            </div>
                <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-6 col-sm-12">
                    <div class="tab-content" id="valueTabsContent">
                        <?php 
                        $i = 0; 
                        while (have_rows('fifth_section_add_tabs')): 
                            the_row(); 
                            $content = get_sub_field('put_the_content');
                            $fifth_section_add_image = get_sub_field('fifth_section_add_image');
                            $fifth_section_add_heading = get_sub_field('fifth_section_add_heading');
                            $fifth_section_add_sub_heading = get_sub_field('fifth_section_add_sub_heading');
                            $fifth_section_button_text = get_sub_field('fifth_section_button_text');
                            $fifth_section_button_text_url = get_sub_field('fifth_section_button_text_url');
                            $tab_id = 'tab-' . $i; // Corresponding content id
                        ?>
                            <div
                                class="tab-pane fade <?= ($i === 0) ? 'show active' : '' ?>"
                                id="<?= $tab_id ?>"
                                role="tabpanel"
                                aria-labelledby="<?= $tab_id ?>-tab"
                            >
                                <div class="our-value-right-card">
                                    <div class="our-value-right-card-img">
                                        <img
                                            src="<?php echo esc_url($fifth_section_add_image['url']); ?>"
                                            alt="<?php echo esc_attr($fifth_section_add_heading); ?>"
                                        />
                                    </div>
                                    <div class="our-value-right-card-content">
                                        <h3><?php echo esc_html($fifth_section_add_heading); ?></h3>
                                        <h4><?php echo esc_html($fifth_section_add_sub_heading); ?></h4>
                                        <a href="<?php echo esc_html($fifth_section_button_text_url); ?>" class="red-button"><?php echo esc_html($fifth_section_button_text); ?></a>
                                    </div>
                                </div>
                            </div>
                        <?php 
                            $i++; 
                        endwhile; 
                        ?>
                    </div>
                </div>
            </div>

          </div>
        </div>
      </section>
      <!-- fifth section end -->
      <!-- Sixth section start -->
      <section class="sixth-sec">
        <div class="container">
            <?php if( get_field('sixth_section_add_heading') ): ?>	
                <div class="heading-cration">
                  <h2><?php the_field('sixth_section_add_heading') ?></h2>
                </div>
            <?php endif; ?>
          <div class="sixth-sec-card">
            <?php
                while (have_rows('sixth_section_card')): the_row();
                    $sixth_section_add_image = get_sub_field('sixth_section_add_image');
                    $sixth_section_add_heading = get_sub_field('sixth_section_add_heading');
                    $sixth_section_add_content = get_sub_field('sixth_section_add_content');
            ?>
            <div class="sixth-sec-card-all">
              <div class="sixth-sec-card-img">
                <img src="<?php echo esc_url($sixth_section_add_image['url']); ?>" />
              </div>
              <div class="sixth-sec-card-content">
                <h3><?php echo $sixth_section_add_heading ?></h3>
                <p><?php echo $sixth_section_add_content ?></p>
              </div>
            </div>
            <?php endwhile; ?>
          </div>
        </div>
      </section>
      <!-- Sixth section end -->
      <!-- Seventh section start -->
      <section class="seventh-sec">
        <div class="container">
        <?php if( get_field('seventh_section_add_heading') ): ?>	
            <div class="heading-cration">
                <h2><?php the_field('seventh_section_add_heading') ?></h2>
            </div>
        <?php endif; ?>
          <div class="seventh-sec-slid">
            <div class="owl-carousel owl-theme slide-two">

              <?php
                  $page = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : get_query_var( 'page' );
                      if(!$page) $page = 1;
                  $args = array(
                      'post_type'         =>		'post',
                      'posts_per_page'    =>		5,
                      'paged'				=>		$page
                  );
                  $query = new WP_Query($args);
                  if ($query->have_posts()) :
                      while ($query->have_posts()) : $query->the_post();
                      $id    =    $query->ID; 
              ?>
                    <div class="item">
                        <div class="seventh-card-wrapper">
                            <div class="seventh-card-wrapper-img">
                            <?php
                            if ( has_post_thumbnail() ) {
                                the_post_thumbnail();
                            }
                                else {
                                    echo '<img src="' . get_bloginfo( 'stylesheet_directory' )
                                    . '/public/images/placeholder.png" />';
                                }
                            ?>
                            </div>
                            <div class="seventh-card-wrapper-content">
                            <h3><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/calendert.svg" /> <?php the_time('M j, Y'); ?></h3>
                            <p><?php the_title(); ?> <a href="<?php the_permalink(); ?>"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/red-right-icon.svg"></a></p>
                            </div>
                        </div>
                    </div>
                  <?php endwhile; ?>
              <?php endif; wp_reset_query(); ?>

            </div>
          </div>
        </div>
      </section>
      <!-- Seventh section end -->
      <!-- Eighth section start -->
      <section class="eighth-sec">
        <div class="container">
          <div class="eighth-sec-wrapper">
            <div class="row">
              <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-12 col-sm-12">
                  <div class="sec-line"></div>
              </div>
              <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-12 col-sm-12">
                <div class="heading-cration">
                <?php if( get_field('form_add_heading', 'options') ): ?>	
                    <h2><?php the_field('form_add_heading', 'options') ?></h2>
                <?php endif; ?>
                  <div class="form-wrapper">
                    <div class="form">
                        <?php echo do_shortcode('[contact-form-7 id="00c16df" title="Contact form"]') ?>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="contact-img">
              <?php $form_add_image = get_field('form_add_image', 'options');
                if (!empty($form_add_image)) : ?>
                  <img src="<?php echo esc_url($form_add_image['url']); ?>" />
              <?php endif; ?>
            </div>
          </div>
        </div>
        <div class="follow-num">
          <div class="container">
            <div class="follow-num-content">
              <div class="icon-phones">
                <img src="<?php the_field('form_add_phone_icon', 'options') ?>" /> 
                <a href="tel:<?php the_field('form_add_phone_number_one', 'options') ?>"><?php the_field('form_add_phone_number_one', 'options') ?></a> | 
                <a href="tel:<?php the_field('form_add_phone_number_two', 'options') ?>"><?php the_field('form_add_phone_number_two', 'options') ?></a>
              </div>
              <div class="icon-phones">
                <img src="<?php the_field('form_add_linkdin_icon', 'options') ?>" />
                <a href="<?php the_field('form_add_linkdin_url', 'options') ?>"><?php the_field('form_add_linkdin_text', 'options') ?></a>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- Eighth section end -->
    </main>
    <!-- main end  -->
<?php get_footer(); ?>