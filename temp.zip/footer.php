    <!-- footer start  -->
    <footer class="footer-sec">
      <div class="container">
        <div class="footer-sec-top">
          <div class="row">
            <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-12 col-sm-12 p-0">
              <?php $logoImage = get_field('Footer_add_logo', 'options');
                if (!empty($logoImage)) : ?>
                  <a class="footer-logo" href="<?php echo esc_url(home_url('/')); ?>">
                    <img src="<?php echo esc_url($logoImage['url']); ?>" alt="Transplex Logo"/>
                  </a>
              <?php endif; ?>
            </div>
            <div class="col-xl-9 col-xl-9 col-lg-9 col-md-12 col-sm-12">
              <?php $menu = (new Menu('footerHenuOne')) 
							->setMenuClass('')
							->setListClass('')
							->setLinkClass('')
							?>
							<?php $menu->showMenu() ?>
            </div>
          </div>
        </div>
      </div>
      <div class="footer-sec-btm">
      <div class="container">
        <?php $menu = (new Menu('footerCopyright')) 
							->setMenuClass('')
							->setListClass('')
							->setLinkClass('')
							?>
				<?php $menu->showMenu() ?>
      </div>
    </div>
    </footer>
    <!-- footer end -->
	<?php wp_footer(); ?>
  </body>
</html>
