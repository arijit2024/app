<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes(); ?>>

<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />

<title><?php bloginfo('name'); ?> <?php if ( is_single() ) { ?> &raquo; Blog Archive <?php } ?> <?php wp_title(); ?></title>

<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen" />
<link rel="stylesheet" href="<?php bloginfo('template_url'); ?>/print.css" type="text/css" media="print" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<link rel="icon" type="image/x-icon" href="<?php echo get_stylesheet_directory_uri(); ?>/images/fab.png">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css"/>
<?php wp_head(); ?>
</head>

<body>
    <!-- header start  -->
    <header class="header-sec">
      <nav class="navbar navbar-expand-lg bg-body-tertiary">
        <div class="container">
          <?php $logoImage = get_field('header_add_logo', 'options');
            if (!empty($logoImage)) : ?>
              <a class="navbar-brand" href="<?php echo esc_url(home_url('/')); ?>"
                ><img src="<?php echo esc_url($logoImage['url']); ?>" alt="Transplex Logo"
              /></a>
          <?php endif; ?>
          <button
            class="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <?php wp_nav_menu( array('menu' => '', 'theme_location' => 'headerHenu', 'depth' => 0, 'container' => false, 'menu_class' => 'navbar-nav mx-auto mb-2 mb-lg-0', 'walker' => new wp_bootstrap_navwalker())); ?>
          <?php if( get_field('header_add_button_text', 'options') ): ?>	
              <div class="contact-us">
                <a href="<?php the_field('header_add_button_text_link', 'options') ?>" class="blue-button"><?php the_field('header_add_button_text', 'options') ?></a>
              </div>
          <?php endif; ?>
          </div>
        </div>
      </nav>
    </header>
    <!-- header end  -->
